<?php
/**
 * Name: Default
 * Description: Default template for PSeCommerce invoice
 */
//only for information