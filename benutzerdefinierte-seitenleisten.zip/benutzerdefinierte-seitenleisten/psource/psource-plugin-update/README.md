=== Angepasste Version des Update-Checkers ===

Bitte 'psource-plugin-updater' an das jeweilige Plugin (Sprachfiles) anpassen.