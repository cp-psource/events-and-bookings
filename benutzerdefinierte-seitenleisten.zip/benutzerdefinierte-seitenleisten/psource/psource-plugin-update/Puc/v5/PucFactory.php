<?php

namespace Psource\PluginUpdateChecker\v5;

if ( !class_exists(PucFactory::class, false) ):

	class PucFactory extends \Psource\PluginUpdateChecker\v5p0\PucFactory {
	}

endif;
