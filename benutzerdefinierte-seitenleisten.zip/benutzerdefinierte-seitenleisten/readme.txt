=== PS Power-Seitenleisten ===
Contributors: DerN3rd (WMS N@W)
Donate link: https://n3rds.work/spendenaktionen/unterstuetze-unsere-psource-free-werke/
Tags: sidebars, widgets, custom, benutzerdefiniert
Requires at least: 4.9
Tested up to: 5.6
Stable tag: 3.5.8
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Ermöglicht das Erstellen von Widget-Bereichen und benutzerdefinierten Seitenleisten. Ersetze ganze Seitenleisten oder einzelne Widgets für bestimmte Beiträge und Seiten.

== Description ==


[POWERED BY PSOURCE](https://n3rds.work/psource_kategorien/psource-plugins/)
Online Geld verdienen macht dieses mächtige Leichtgewicht von eCommerce Plugin im Nu Kinderleicht.

[Projektseite](https://n3rds.work/piestingtal_source/ps-power-seitenleisten/)
[Handbuch](https://n3rds.work/docs/)
[Supportforum](https://n3rds.work/forums/forum/)
[GitHub](https://github.com/piestingtal-source/benutzerdefinierte-seitenleisten)

== Mehr PSOURCE ==

= Finde mehr Piestingtal.Source =

Wirf einen Blick in unser [PSOURCE Sortiment](https://n3rds.work/psource_kategorien/psource-plugins/) und hole noch mehr aus Deinem WordPress/ClassicPress!

Halte Dich mit unserem [Newsletter](https://n3rds.work/webmasterservice-n3rdswork-digalize-das-piestingtal/newsletter-management/) über unsere Piestingtal.Source informiert!

== Hilf uns ==

Viele, viele Kaffees konsumieren wir während wir an unseren Plugins und Themes arbeiten.
Wie wärs? Möchtest Du uns mit einer Kaffee-Spende bei der Arbeit an unseren Plugins unterstützen?

= Unterstütze uns =

Mach eine [Spende per Überweisung oder PayPal](https://n3rds.work/spendenaktionen/unterstuetze-unsere-psource-free-werke/) wir Danken Dir!

Halte Dich mit unserem [Newsletter](https://n3rds.work/webmasterservice-n3rdswork-digalize-das-piestingtal/newsletter-management/) über unsere Piestingtal.Source informiert!


== ChangeLog ==

= 3.5.8 = DerN3rd =

* PO Datei hinzugefügt
* Psource Updater 1.2 (Securtiy Fixes, PhP8 Anpassungen)

= 3.5.7 = DerN3rd =

* Erste Veröffentlichung

