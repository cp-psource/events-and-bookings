=== PS Affiliate ===
Contributors: DerN3rd (WMS N@W)
Donate link: https://n3rds.work/spendenaktionen/unterstuetze-unsere-psource-free-werke/
Tags: multisite, affiliate, provision, marketing
Requires at least: 4.9
Tested up to: 5.6
Stable tag: 3.2.7
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Dieses Plugin fügt Deiner Seite ein einfaches Affiliate-System hinzu. Verfolge eingehende Klicks von Affiliate-Referer-Links, die Integration der Auftragsverfolgung in PSeCommerce, bezahlte Bloghosting-Anmeldungen und bezahlte Mitgliedschaftsanmeldungen.

== Description ==

Affiliates fördern das Geschäft, indem Du alle Deine Benutzer zu einem Teil Deines Marketingteams machst.

Integriert oder eigenständig
PS Affiliate lässt sich perfekt in unsere PS Bloghosting, PSeCommerce- und PS Mitgliedschaften-Plugins integrieren und ermöglicht es Dir, 
Deinen Besuchern einen Anteil am Gewinn zu bieten, indem sie für Deine Webseite werben.

[POWERED BY PSOURCE](https://n3rds.work/psource_kategorien/psource-plugins/)

[Projektseite](https://n3rds.work/piestingtal_source/ps-affiliate-plugin/)
[Handbuch](https://n3rds.work/docs/ps-affiliate-plugin-handbuch/)
[Supportforum](https://n3rds.work/forums/forum/psource-support-foren/ps-affiliate-plugin-supportforum/)
[GitHub](https://github.com/piestingtal-source/affiliate)

== Mehr PSource ==

Dieses Plugin arbeitet natürlich mit anderen PSource Plugins zusammen!
Hier bitte, wir haben sie Dir hier zusammengestellt:

Mit [PSeCommerce](https://n3rds.work/piestingtal_source/psecommerce-shopsystem/) kannst Du Deinen Partnern Provisionen für Verkäufe Deiner Produkte anbieten.

[Bloghosting](https://n3rds.work/piestingtal_source/ps-bloghosting-multisite-next-level-plugin/) bezahlt Provisionen für epfohlene Abschlüsse eines Webhostings.

Bezahle Provisionen für neue Mitglieder dank des [PS Mitgliedschaften](https://n3rds.work/piestingtal_source/ps-mitgliedschaften-plugin/) Plugins.

Wirf einen Blick in unser [PSOURCE Sortiment](https://n3rds.work/psource_kategorien/psource-plugins/) und hole noch mehr aus Deinem WordPress/ClassicPress!

Halte Dich mit unserem [Newsletter](https://n3rds.work/webmasterservice-n3rdswork-digalize-das-piestingtal/newsletter-management/) über unsere Piestingtal.Source informiert!

== Hilf uns ==

Viele, viele Kaffees konsumieren wir während wir an unseren Plugins und Themes arbeiten.
Wie wärs? Möchtest Du uns mit einer Kaffee-Spende bei der Arbeit an unseren Plugins unterstützen?

= Unterstütze uns =

Mach eine [Spende per Überweisung oder PayPal](https://n3rds.work/spendenaktionen/unterstuetze-unsere-psource-free-werke/) wir Danken Dir!

Halte Dich mit unserem [Newsletter](https://n3rds.work/webmasterservice-n3rdswork-digalize-das-piestingtal/newsletter-management/) über unsere Piestingtal.Source informiert!

== ChangeLog ==

= 3.2.7 = DerN3rd =

* Psource Updater 1.2 (PhP8 Fixes, Security Fixes)

= 3.2.6 = DerN3rd =

Umstellung auf PSource Updater v1.1

= 3.2.5 = DerN3rd =

* Overhauled von WPMUDEV
* Release WMS N@W Netzwerksuche