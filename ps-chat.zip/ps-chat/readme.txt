=== PS Chat ===
Contributors: DerN3rd (WMS N@W)
Donate link: https://n3rds.work/spendenaktionen/unterstuetze-unsere-psource-free-werke/
Tags: multisite, abstimmung, voting, post,
Requires at least: 4.9
Tested up to: 5.6
Stable tag: 2.4.5
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Erlaube Deinen Usern, mit Dir oder anderen Usern zu chatten. Inkl. Gruppenchats für BuddyPress. Keine Drittanbieter, keine externen Abo-Kosten!

== Description ==

Das mächtigste Livechat Tool zum selbsthosten für WordPress. Vorsicht, je nach Auslastung kann der Betrieb des Chat-Tools eine hohe Server-Last verursachen.
Manche Hosting-Anbieter oder V-Server könnten Dich für einen Spammer halten. Stelle sicher das Du entweder niedrigere Abfrageintervalle einstellst oder ein
entsprechendes Hosting, zB. einen Root-Server Dein Eigen nennst.

[POWERED BY PSOURCE](https://n3rds.work/psource_kategorien/psource-plugins/)
Online Geld verdienen macht dieses mächtige Leichtgewicht von eCommerce Plugin im Nu Kinderleicht.

[Projektseite](https://n3rds.work/piestingtal_source/ps-chat-wordpress-livechatsystem/)
[Handbuch](https://n3rds.work/docs/ps-chat-handbuch/)
[Supportforum](https://n3rds.work/forums/forum/psource-support-foren/ps-chat-supportforum/)
[GitHub](https://github.com/piestingtal-source/ps-chat)

== Mehr PSOURCE ==

= Finde mehr Piestingtal.Source =

Wirf einen Blick in unser [PSOURCE Sortiment](https://n3rds.work/psource_kategorien/psource-plugins/) und hole noch mehr aus Deinem WordPress/ClassicPress!

Halte Dich mit unserem [Newsletter](https://n3rds.work/webmasterservice-n3rdswork-digalize-das-piestingtal/newsletter-management/) über unsere Piestingtal.Source informiert!

== Hilf uns ==

Viele, viele Kaffees konsumieren wir während wir an unseren Plugins und Themes arbeiten.
Wie wärs? Möchtest Du uns mit einer Kaffee-Spende bei der Arbeit an unseren Plugins unterstützen?

= Unterstütze uns =

Mach eine [Spende per Überweisung oder PayPal](https://n3rds.work/spendenaktionen/unterstuetze-unsere-psource-free-werke/) wir Danken Dir!

Halte Dich mit unserem [Newsletter](https://n3rds.work/webmasterservice-n3rdswork-digalize-das-piestingtal/newsletter-management/) über unsere Piestingtal.Source informiert!


== ChangeLog ==

= 2.4.5 = DerN3rd = 

* Deprecated: Optional parameter Fix
* Für PhP 8.1 getestet
* Deprecated jQuery.fn.resize() Fix
* Deprecated .click() fix
* Bugfix in Textstring
* Psourceupdater 1.2

= 2.4.4 = DerN3rd =

* Fix: Deprecated locale.php
* Neues Options-Icon
* Besseres Emoticons-CSS

= 2.4.3 = DerN3rd =

* Plugin Textdomain Angepasst
* Fix: Deprecated session.php

= 2.4.2 = DerN3rd =

* Admin Dashicon hinzugefügt
* PhP8 Fix Frontend-Chat
* PhP8 Fixes Dashboard
* Leeren Tooltipbalken im Dashboard ausgeblendet
* Widgets unter "PSC" gruppiert

= 2.4.1 = DerN3rd =

* Fixed Profilbild bei Chatanfrage
* Deleted Plugin Ajax 

= 2.3.5 = DerN3rd =

* AutoUpdate Support für die automatische Plugin-Aktualisierung integriert

= 2.3.3 = DerN3rd =

* Neue Grafische Elemente eingefügt
* Noch mehr Code erneuert


= 2.3.2 = DerN3rd =

* Added Mehr Emojis
* Fixed Veralteten PHP Code
* Fixed Emoji-Menü

= 2.3.0 = DerN3rd =

* Added Verbesserungen an Texten
* Fixed Voreinstellungen für Chatdarstellung
* Added Moderneres CSS begonnen

= 2.3.8 = DerN3rd =

* Added: Neue Emojis
* Fixed CSS Emoji-Box

= 2.3.3 = DerN3rd =

* Fixed: Hotfix für Gutenberg bei Deutscher Sprache

= 2.2.0 = DerN3rd =

* Fixed: Probleme mit WordPress 5.0
* Updated: Übersetzung auf Deutsch
* Updated: Neue Hilferessourcen

= 1.0.0 =

* Initial release


