<?php
/**
 * PSource Plugin Updater Library 1.2
 * https://n3rds.work/
 *
 * Copyright 2022 DerN3rd
 * Released under the MIT license. See license.txt for details.
 */

require dirname(__FILE__) . '/load-v5p0.php';